const mongoose = require("mongoose");
const Joi = require("joi");
const jwt = require("jsonwebtoken");
const config = require("config");

const toySchema = new mongoose.Schema({
    name: String,
    info: String,
    category: String,
    img_url: String,
    price: Number,
    date: {
      type: Date, default: Date.now
    }
});
  
  const toyModel = mongoose.model("toys",toySchema);
  exports.toyModel = toyModel;

//Joi Validation 
const validToy = (_userObj) => {
  //any == כל סוג טייפ
  let schema = Joi.object({
    _id: Joi.any(),
    name:Joi.string().min(2).max(50).required(),
    info:Joi.string().min(2).max(50).required(),
    category: Joi.string().min(2).max(50),
    img_url:Joi.string().min(1).max(1000).required(),
    price:Joi.number().min(1).max(10000).required()  
  })
  return schema.validate(_userObj);
}


exports.validToy = validToy;

