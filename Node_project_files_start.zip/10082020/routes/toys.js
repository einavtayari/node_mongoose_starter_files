const express = require('express');
const router = express.Router();
const { toyModel, validToy } = require("../models/toys_model")


//GET- show all data in collection 
// http://localhost:3000/toys
router.get(`/`, async (req,res,next)=>{
    toyModel.find({})
    .then(data => {
        res.json(data);
      })
      .catch(err => {
        res.status(400).json(err);
      })
})

//SEARCH- by query, presents the search word among chosen properties
// http://localhost:3000/toys/search/?q=<word>
router.get("/search", (req, res) => {
    let searchQ = req.query.q;
    let mySearch = new RegExp(`${searchQ}`); 
  
    toyModel.find({$or:[{name:mySearch},{category:mySearch}]})
    .then(data => {
      res.json(data)
    })
    .catch(err => {
      res.status(400).json({err})
    })
});

//LIMIT, SKIP items per page
// http://localhost:3000/toys/?page= <number>
// 20 items per page
router.get("/", (req, res) => {
    let perPage = 20;
    let page = req.params.page;
    if(page < 0){
        page = 0;
    }
  
    toyModel.find({})
    .limit(perPage)
    .skip(page * perPage)
    .then(data => {
      res.json(data)
    })
    .catch(err => {
      res.status(400).json({err})
    })
});

//POST- add items to collection
// http://localhost:3000/toys/add
router.post("/add", (req, res) => {
    let valid = validToy(req.body);
    if (!valid.error) {
      toyModel.insertMany([req.body])
        .then(data => {
          res.json(data)
        })
        .catch(err => {
          res.status(400).json({ err })
        })
    }
    else {
      res.status(400).json(valid.error.details);
    }
})


//PUT- edit item in the collection by id
// http://localhost:3000/toys/edit
router.put(`/edit`,(req,res,next)=>{
    let valid = validToy(req.body);
    if (!valid.error) {
      toyModel.updateOne({_id:req.body._id}, req.body)
        .then(data => {
          res.json(data)
        })
        .catch(err => {
          res.status(400).json({ err })
        })
    }
    else {
      res.status(400).json(valid.error.details);
    }
})


//POST- delete item from collection by id
// http://localhost:3000/toys/del/:idDel
router.post(`/del/:idDel`,(req,res,next)=>{
    let idDel = req.params.idDel;

    toyModel.deleteOne({_id:idDel})
        .then(data => {
          res.json(data)
        })
        .catch(err => {
          res.status(400).json({ err })
        })
})


module.exports = router;
