const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');

const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const toysR = require('./routes/toys');
const mongo = require('./dbs/mongo_connected');

const app = express();
app.all('*', function (req, res, next) {
  // בודק אם הגיעה בקשה מדפדפן ולא נניח 
  // POSTMAN או אפליקציה כלשהי
  if (!req.get('Origin')) return next();
  // * במציאות בפרוקדשן נשנה את הכוכבית לדומיין /דומניים ספציפים שנרצ לעבוד מולם
  res.set('Access-Control-Allow-Origin', '*');
  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE");
  // header הרשאות של
  res.set('Access-Control-Allow-Headers', `X-Requested-With,Content-Type,x-auth-token`);
  next();
});

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/toys', toysR);

// catch 404 and forward to error handler
app.use((req, res, next)=> {
  next(createError(404));
});

// error handler
app.use((err, req, res, next)=> {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
